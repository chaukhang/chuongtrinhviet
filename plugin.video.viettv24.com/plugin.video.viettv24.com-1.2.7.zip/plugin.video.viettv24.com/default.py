#!/usr/bin/python
#coding=utf-8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , base64 , json , shutil , zipfile
from math import radians , sqrt , sin , cos , atan2
from operator import itemgetter
import xmltodict
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.viettv24.com'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
iiiii = int ( sys . argv [ 1 ] )
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #i1I11i = xbmc . translatePath ( os . path . join ( i1I11i , "temp.jpg" ) )
 #urllib . urlretrieve ( 'https://googledrive.com/host/0B-ygKtjD8Sc-S04wUUxMMWt5dmM/images/viettv24.jpg' , i1I11i )
 #OoOoOO00 = xbmcgui . WindowDialog ( )
 #I11i = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , i1I11i )
 #OoOoOO00 . addControl ( I11i )
 #OoOoOO00 . doModal ( )
 if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
 I11iIi1I = IiiIII111iI ( IiII ( "ghjl" , "z9ze3KGXmeDP19jTld7T0dvc4J6bls3b1Jfd29zazdHGztPYzA==" ) )
 if 28 - 28: Ii11111i * iiI1i1
 for i1I1ii1II1iII , oooO0oo0oOOOO in eval ( I11iIi1I ) :
  O0oO ( i1I1ii1II1iII , oooO0oo0oOOOO , 'indexgroup' , i1I11i . replace ( "temp.jpg" , "icon.png" ) )
 o0oO0 = xbmc . getSkinDir ( )
 if o0oO0 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
  if 100 - 100: i11Ii11I1Ii1i
def Ooo ( url ) :
 o0oOoO00o = IiiIII111iI ( url )
 i1oOOoo00O0O = re . compile ( '<name>(.+?)</name>' ) . findall ( o0oOoO00o )
 if len ( i1oOOoo00O0O ) == 1 :
  i1111 = re . compile ( '<item>(.+?)</item>' ) . findall ( o0oOoO00o )
  for i11 in i1111 :
   I11 = ""
   Oo0o0000o0o0 = ""
   oOo0oooo00o = ""
   if "/title" in i11 :
    Oo0o0000o0o0 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11 ) [ 0 ]
   if "/link" in i11 :
    oOo0oooo00o = re . compile ( '<link>(.+?)</link>' ) . findall ( i11 ) [ 0 ]
   if "/thumbnail" in i11 :
    I11 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11 ) [ 0 ]
   oO0o0o0ooO0oO ( i1oOOoo00O0O [ 0 ] + "/" + Oo0o0000o0o0 , oOo0oooo00o , 'play' , I11 )
  o0oO0 = xbmc . getSkinDir ( )
  if o0oO0 == 'skin.xeebo' :
   xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
 else :
  for oo0o0O00 in i1oOOoo00O0O :
   O0oO ( oo0o0O00 , url + "&n=" + oo0o0O00 , 'index' , '' )
   if 68 - 68: o00oo . iI1OoOooOOOO + i11iiII
def I1iiiiI1iII ( url ) :
 IiIi11i = url . split ( "&n=" ) [ 1 ]
 o0oOoO00o = IiiIII111iI ( url )
 iIii1I111I11I = re . compile ( '<channel>(.+?)</channel>' ) . findall ( o0oOoO00o )
 for OO00OooO0OO in iIii1I111I11I :
  if IiIi11i in OO00OooO0OO :
   i1111 = re . compile ( '<item>(.+?)</item>' ) . findall ( OO00OooO0OO )
   for i11 in i1111 :
    I11 = ""
    Oo0o0000o0o0 = ""
    oOo0oooo00o = ""
    if "/title" in i11 :
     Oo0o0000o0o0 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11 ) [ 0 ]
    if "/link" in i11 :
     oOo0oooo00o = re . compile ( '<link>(.+?)</link>' ) . findall ( i11 ) [ 0 ]
    if "/thumbnail" in i11 :
     I11 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11 ) [ 0 ]
    oO0o0o0ooO0oO ( IiIi11i + "/" + Oo0o0000o0o0 , oOo0oooo00o , 'play' , I11 )
 o0oO0 = xbmc . getSkinDir ( )
 if o0oO0 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 28 - 28: iIii1
def IiII ( k , e ) :
 oOOoO0 = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for O0OoO000O0OO in range ( len ( e ) ) :
  iiI1IiI = k [ O0OoO000O0OO % len ( k ) ]
  II = chr ( ( 256 + ord ( e [ O0OoO000O0OO ] ) - ord ( iiI1IiI ) ) % 256 )
  oOOoO0 . append ( II )
 return "" . join ( oOOoO0 )
 if 57 - 57: ooOoo0O
def OooO0 ( source , dest_dir ) :
 with zipfile . ZipFile ( source ) as II11iiii1Ii :
  for OO0oOoo in II11iiii1Ii . infolist ( ) :
   O0o0Oo = OO0oOoo . filename . split ( '/' )
   i1I11i = dest_dir
   for Oo00OOOOO in O0o0Oo [ : - 1 ] :
    O0O , Oo00OOOOO = os . path . splitdrive ( Oo00OOOOO )
    O00o0OO , Oo00OOOOO = os . path . split ( Oo00OOOOO )
    if Oo00OOOOO in ( os . curdir , os . pardir , '' ) : continue
    i1I11i = os . path . join ( i1I11i , Oo00OOOOO )
   II11iiii1Ii . extract ( OO0oOoo , i1I11i )
   if 44 - 44: O0o / o0 + I11ii1 / o0OO0oo0oOO . i11Ii11I1Ii1i
def I1iii ( url ) :
 i1I11i = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 i1iiI11I = xbmc . translatePath ( os . path . join ( i1I11i , "tmp" ) )
 if os . path . exists ( i1iiI11I ) :
  shutil . rmtree ( i1iiI11I )
 os . makedirs ( i1iiI11I )
 if ".zip" in url :
  iiii = xbmc . translatePath ( os . path . join ( i1iiI11I , "temp.zip" ) )
  urllib . urlretrieve ( url , iiii )
  OooO0 ( iiii , i1iiI11I )
 else :
  oO0o0O0OOOoo0 = xbmc . translatePath ( os . path . join ( i1iiI11I , "temp.jpg" ) )
  urllib . urlretrieve ( url , oO0o0O0OOOoo0 )
 xbmc . executebuiltin ( "SlideShow(%s,recursive)" % i1iiI11I )
 if 48 - 48: iIIi1iI1II111 + iIIi1iI1II111 - o00oo . o0OO0oo0oOO / ii11i
def OoOOO00oOO0 ( url , title ) :
 if ( "youtube" in url ) :
  oOoo = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( url )
  iIii11I = oOoo [ 0 ] [ len ( oOoo [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
  url = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' + iIii11I . replace ( '?' , '' )
  xbmc . executebuiltin ( "xbmc.PlayMedia(" + url + ")" )
 else :
  if url . isdigit ( ) :
   OOO0OOO00oo = "http://www.viettv24.com/main/getStreamingServer.php"
   IiII = urllib . urlencode ( { 'strname' : '%s-' % url } )
   url = urllib2 . urlopen ( OOO0OOO00oo , data = IiII ) . read ( )
   print url
  title = urllib . unquote_plus ( title )
  Iii111II = xbmc . PlayList ( 1 )
  Iii111II . clear ( )
  iiii11I = xbmcgui . ListItem ( title )
  iiii11I . setInfo ( 'video' , { 'Title' : title } )
  Ooo0OO0oOO = xbmc . Player ( )
  Iii111II . add ( url , iiii11I )
  Ooo0OO0oOO . play ( Iii111II )
  if 50 - 50: ii1IiI1i
def Ii1i11IIii1I ( lat1 , lon1 , lat2 , lon2 ) :
 lat1 = radians ( lat1 )
 lon1 = radians ( lon1 )
 lat2 = radians ( lat2 )
 lon2 = radians ( lon2 )
 if 52 - 52: i11Ii11I1Ii1i - oOooOoO0Oo0O + ooOoo0O + ooOoo0O - i11Ii11I1Ii1i / I11ii1
 I1I = lon1 - lon2
 if 24 - 24: o00oo
 o0Oo0O0Oo00oO = 6372.8
 if 39 - 39: o0 - i1 * Ii11111i % i11Ii11I1Ii1i * i1 % i1
 OoOOOOO = sqrt (
 ( cos ( lat2 ) * sin ( I1I ) ) ** 2
 + ( cos ( lat1 ) * sin ( lat2 ) - sin ( lat1 ) * cos ( lat2 ) * cos ( I1I ) ) ** 2
 )
 iIi1i111II = sin ( lat1 ) * sin ( lat2 ) + cos ( lat1 ) * cos ( lat2 ) * cos ( I1I )
 OoOO00O = atan2 ( OoOOOOO , iIi1i111II )
 return o0Oo0O0Oo00oO * OoOO00O
 if 53 - 53: Ii11111i % oOooOoO0Oo0O - iiI1i1
def IiiIII111iI ( url ) :
 oOo0oooo00o = ""
 if os . path . exists ( url ) == True :
  oOo0oooo00o = open ( url ) . read ( )
 else :
  oO000Oo000 = urllib2 . Request ( url )
  oO000Oo000 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
  i111IiI1I = urllib2 . urlopen ( oO000Oo000 )
  oOo0oooo00o = i111IiI1I . read ( )
  i111IiI1I . close ( )
  if 70 - 70: ooOoo0O . IIIiiIIii / i11Ii11I1Ii1i . ooOoo0O - iIIi1iI1II111 / o0
 if ( "xml" in url ) :
  oOo0oooo00o = IiII ( "umbala" , oOo0oooo00o )
 oOo0oooo00o = '' . join ( oOo0oooo00o . splitlines ( ) ) . replace ( '\'' , '"' )
 oOo0oooo00o = oOo0oooo00o . replace ( '\n' , '' )
 oOo0oooo00o = oOo0oooo00o . replace ( '\t' , '' )
 oOo0oooo00o = re . sub ( '  +' , ' ' , oOo0oooo00o )
 oOo0oooo00o = oOo0oooo00o . replace ( '> <' , '><' )
 return oOo0oooo00o
 if 62 - 62: ii11i * iiI1i1
def oO0o0o0ooO0oO ( name , url , mode , iconimage ) :
 i1OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 Oo0oOOo = True
 Oo0OoO00oOO0o = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 Oo0OoO00oOO0o . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Oo0oOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1OOO , listitem = Oo0OoO00oOO0o )
 return Oo0oOOo
 if 80 - 80: iI1OoOooOOOO + i11iiII - i11iiII % O0o
def O0oO ( name , url , mode , iconimage ) :
 i1OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 Oo0oOOo = True
 Oo0OoO00oOO0o = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 Oo0OoO00oOO0o . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Oo0oOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1OOO , listitem = Oo0OoO00oOO0o , isFolder = True )
 return Oo0oOOo
 if 63 - 63: ii1IiI1i - o00oo + iIIi1iI1II111 % iIii1 / ii11i / i11Ii11I1Ii1i
def O0o0O00Oo0o0 ( parameters ) :
 O00O0oOO00O00 = { }
 if 11 - 11: o0 . o00oo
 if parameters :
  o0oo0oOo = parameters [ 1 : ] . split ( "&" )
  for o000O0o in o0oo0oOo :
   iI1iII1 = o000O0o . split ( '=' )
   if ( len ( iI1iII1 ) ) == 2 :
    O00O0oOO00O00 [ iI1iII1 [ 0 ] ] = iI1iII1 [ 1 ]
 return O00O0oOO00O00
 if 86 - 86: i11iiII
if os . path . exists ( O0O0OO0O0O0 ) == False :
 os . mkdir ( O0O0OO0O0O0 )
OOoo0O = os . path . join ( O0O0OO0O0O0 , 'visitor' )
if 67 - 67: i11iIiiIii - OOooo000oo0 % o00oo . iIIi1iI1II111
if os . path . exists ( OOoo0O ) == False :
 from random import randint
 o0oo = open ( OOoo0O , "w" )
 o0oo . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 o0oo . close ( )
 if 91 - 91: o0
def iiIii ( utm_url ) :
 ooo0O = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  oO000Oo000 = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : ooo0O }
 )
  i111IiI1I = urllib2 . urlopen ( oO000Oo000 ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return i111IiI1I
 if 75 - 75: i11Ii11I1Ii1i % i11Ii11I1Ii1i . I11ii1
def III1iII1I1ii ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  oOOo0 = "4.2.8"
  oo00O00oO = open ( OOoo0O ) . read ( )
  iIiIIIi = "VietTV24"
  ooo00OOOooO = "UA-52209804-2"
  O00OOOoOoo0O = "www.viettv24.com"
  O000OOo00oo = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   oo0OOo = O000OOo00oo + "?" + "utmwv=" + oOOo0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iIiIIIi ) + "&utmac=" + ooo00OOOooO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oo00O00oO , "1" , "1" , "2" ] )
   if 64 - 64: iIii1
   if 22 - 22: IIIiiIIii + ooOoo0O % o00oo
   if 9 - 9: oOooOoO0Oo0O
   if 62 - 62: i11iiII / Ii11111i + ooOoo0O / Ii11111i . i1
   if 68 - 68: i11iIiiIii % o00oo + i11iIiiIii
  else :
   if group == "None" :
    oo0OOo = O000OOo00oo + "?" + "utmwv=" + oOOo0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iIiIIIi + "/" + name ) + "&utmac=" + ooo00OOOooO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oo00O00oO , "1" , "1" , "2" ] )
    if 31 - 31: i1 . ii1IiI1i
    if 1 - 1: IIIiiIIii / i11Ii11I1Ii1i % O0o * o0 . i11iIiiIii
    if 2 - 2: o00oo * iIii1 - ii11i + ii1IiI1i . iI1OoOooOOOO % O0o
    if 92 - 92: O0o
    if 25 - 25: IIIiiIIii - ii1IiI1i / oOooOoO0Oo0O / i11Ii11I1Ii1i
   else :
    oo0OOo = O000OOo00oo + "?" + "utmwv=" + oOOo0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iIiIIIi + "/" + group + "/" + name ) + "&utmac=" + ooo00OOOooO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oo00O00oO , "1" , "1" , "2" ] )
    if 12 - 12: ii1IiI1i * O0o % OOooo000oo0 % ii11i
    if 20 - 20: i11iiII % ooOoo0O / ooOoo0O + ooOoo0O
    if 45 - 45: iI1OoOooOOOO - o0 - oOooOoO0Oo0O - Ii11111i . i1 / iIIi1iI1II111
    if 51 - 51: iIIi1iI1II111 + O0o
    if 8 - 8: iI1OoOooOOOO * iiI1i1 - ooOoo0O - Ii11111i * i11iiII % ii1IiI1i
    if 48 - 48: iIIi1iI1II111
  print "============================ POSTING ANALYTICS ============================"
  iiIii ( oo0OOo )
  if 11 - 11: iIii1 + oOooOoO0Oo0O - Ii11111i / i11Ii11I1Ii1i + IIIiiIIii . i1
  if not group == "None" :
   i1Iii1i1I = O000OOo00oo + "?" + "utmwv=" + oOOo0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( O00OOOoOoo0O ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + iIiIIIi + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( iIiIIIi ) + "&utmac=" + ooo00OOOooO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , oo00O00oO , "1" , "2" ] )
   if 91 - 91: o00oo + ii1IiI1i . i11iiII * o00oo + ii1IiI1i * IIIiiIIii
   if 80 - 80: O0o % i11iiII % iI1OoOooOOOO - IIIiiIIii + IIIiiIIii
   if 19 - 19: iiI1i1 * OOooo000oo0
   if 14 - 14: O0o
   if 11 - 11: o0 * ii1IiI1i . ii11i % oOooOoO0Oo0O + O0o
   if 78 - 78: Ii11111i . i11iiII + Ii11111i / iIii1 / Ii11111i
   if 54 - 54: iiI1i1 % O0o
   if 37 - 37: iiI1i1 * IIIiiIIii / o0OO0oo0oOO - O0o % i1 . iI1OoOooOOOO
   try :
    print "============================ POSTING TRACK EVENT ============================"
    iiIii ( i1Iii1i1I )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 88 - 88: O0o . i1 * i1 % I11ii1
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 15 - 15: OOooo000oo0 * ii1IiI1i + i11iIiiIii
I1Ii = O0o0O00Oo0o0 ( sys . argv [ 2 ] )
O0oo00o0O = I1Ii . get ( 'mode' )
i1I1I = I1Ii . get ( 'url' )
oo0o0O00 = I1Ii . get ( 'name' )
if type ( i1I1I ) == type ( str ( ) ) :
 i1I1I = urllib . unquote_plus ( i1I1I )
if type ( oo0o0O00 ) == type ( str ( ) ) :
 oo0o0O00 = urllib . unquote_plus ( oo0o0O00 )
 if 12 - 12: i11iIiiIii / Ii11111i
o0O = str ( sys . argv [ 1 ] )
if O0oo00o0O == 'index' :
 III1iII1I1ii ( "Browse" , oo0o0O00 )
 I1iiiiI1iII ( i1I1I )
elif O0oo00o0O == 'indexgroup' :
 III1iII1I1ii ( "Browse" , oo0o0O00 )
 Ooo ( i1I1I )
elif O0oo00o0O == 'play' :
 III1iII1I1ii ( "Play" , oo0o0O00 + "/" + i1I1I )
 if any ( x in i1I1I for x in [ ".jpg" , ".zip" ] ) :
  I1iii ( i1I1I )
 else :
  IiIIii1iII1II = xbmcgui . DialogProgress ( )
  IiIIii1iII1II . create ( 'Brought to you by VietTV24.com' , 'Loading video. Please wait...' )
  OoOOO00oOO0 ( i1I1I , oo0o0O00 )
  IiIIii1iII1II . close ( )
  del IiIIii1iII1II
else :
 III1iII1I1ii ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( o0O ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

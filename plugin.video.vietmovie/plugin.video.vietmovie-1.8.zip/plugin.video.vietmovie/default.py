# -*- coding: utf-8 -*-

# Standard libs
import urllib,urllib2,unicodedata,string,re

# TODO: Uncomment!
import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os

# TODO: XBMC - Fake APIs!
# ================================================

# def addDir(name,url,mode,iconimage):
#   print('------------------------')
#   print(name)
#   print('- URL: ' + url)
#   print('- MODE: ' + str(mode))
#   print('- Icon: ' + iconimage)
#   print('------------------------ \n')

# def playMedia(name,url,iconimage):
#   ok=True
#   print('------------Play Media (Mock) ------------')
#   print(name)
#   print('- URL: ' + url)
#   print('- Icon: ' + iconimage)
#   print('------------------------ \n')
#   return ok

# def endOfItemList():
#   return True

# ================================================


rootURL = "http://phim.megabox.vn/"
browsers = {'User-Agent' : 'Mozilla/5.0 Chrome/39.0.2171.71 Firefox/33.0'}
suffixURL = '|' + urllib.urlencode(browsers)

# TODO: Uncomment!
mysettings=xbmcaddon.Addon(id='plugin.video.vietmovie')
home=mysettings.getAddonInfo('path')
fanart=xbmc.translatePath(os.path.join(home, 'fanart.jpg'))

# ------------------- Utils ----------------------
def encodeURL(url):
  return unicodedata.normalize('NFKD', url.decode('UTF-8')).encode('ascii', 'ignore')

# TODO: Uncomment!
# This function should be put after adding items.
def endOfItemList():
  # Display channels as thumbnail as default.
  xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
  # End of directory.
  xbmcplugin.endOfDirectory(int(sys.argv[1]))

# ------------------- FUNCTIONs -----------------------

def getPageContent(url):
  req = urllib2.Request(url)
  req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0')
  response=urllib2.urlopen(req)
  content=response.read()
  response.close()
  return content

def getFilmTypeList(url):
  content = getPageContent(url)
  # <li><a href="phim-le" title="">Phim le</a></li>
  template = '<li><a href="(.+?)" title="">(.+?)</a></li>'
  pageLinks = re.compile(template).findall(str(content))
  filmTypeList=[]
  count = 0
  for (relativeLink, name) in pageLinks:
    link = url + relativeLink + '/'
    filmTypeList.append((name, link))
  return filmTypeList

# Note: Not include media link now. It will get when user selects a link of film.
def getFilmInfoList(url):
  # print("--------> getFilmInfoList: " + url)
  content = getPageContent(url)
  pattern='a class=".+?" href="(.+?)".*<h3 class=.H3title.>(.+?)</h3>.*\s.*src="(.+?)"'
  pageLinks = re.compile(pattern).findall(str(content))
  filmInfoList = []
  for (link, title, thumb) in pageLinks:
    # print('- Title : ' + title)
    # print('- URL : ' + link)
    # print('- Thumb: ' + thumb)
    filmInfoList.append((title, link, thumb))
  return filmInfoList


def getEpisodeInfoList(pageURL):
  content = getPageContent(pageURL)
  # <li><a id=eps-ID href='PAGE' >TAP-PHIM</a></li>
  template = "<li><a id=eps-(.+?) href='(.+?)' >(.+?)</a></li>"
  pageLinks = re.compile(template).findall(str(content))
  epsInfoList=[]
  # count = 0
  for (epsId, link, eps) in pageLinks:
    epsInfoList.append((eps, link))
  return epsInfoList

def getTitle(link, content):
  template='<a href="' + link + '">(.+?)</a>'
  pageLinks=re.compile(template).findall(str(content))
  return pageLinks[0]

def getMediaLink(url):
  content = getPageContent(url)
  # template = 'onclick="changeStreamUrl(\'(.+?)\');"'
  template = 'var iosUrl = "(.+?)";'
  links = re.compile(template).findall(str(content))
  mediaLink = ''
  if len(links) > 0:
    mediaLink = links[0]
    if 'youtube' in mediaLink:
      mediaLink = mediaLink.replace('https://www.youtube.com/watch?v=', 'plugin://plugin.video.youtube/?action=play_video&videoid=')
    else:
      mediaLink = mediaLink + suffixURL
  return mediaLink

def convertVNChars2NoAccent(str):
  try:
    if str == '': return
    if type(str).__name__ == 'unicode': str = str.encode('utf-8')
    list_pat = ["á|à|ả|ạ|ã|â|ấ|ầ|ẩ|ậ|ẫ|ă|ắ|ằ|ẳ|ặ|ẵ", "Á|À|Ả|Ạ|Ã|Â|Ấ|Ầ|Ẩ|Ậ|Ẫ|Ă|Ắ|Ằ|Ẳ|Ặ|Ẵ",
      "đ", "Đ", "í|ì|ỉ|ị|ĩ", "Í|Ì|Ỉ|Ị|Ĩ", "é|è|ẻ|ẹ|ẽ|ê|ế|ề|ể|ệ|ễ", "É|È|Ẻ|Ẹ|Ẽ|Ê|Ế|Ề|Ể|Ệ|Ễ",
      "ó|ò|ỏ|ọ|õ|ô|ố|ồ|ổ|ộ|ỗ|ơ|ớ|ờ|ở|ợ|ỡ", "Ó|Ò|Ỏ|Ọ|Õ|Ô|Ố|Ồ|Ổ|Ộ|Ỗ|Ơ|Ớ|Ờ|Ở|Ợ|Ỡ",
      "ú|ù|ủ|ụ|ũ|ư|ứ|ừ|ử|ự|ữ", "Ú|Ù|Ủ|Ụ|Ũ|Ư|Ứ|Ừ|Ử|Ự|Ữ", "ý|ỳ|ỷ|ỵ|ỹ", "Ý|Ỳ|Ỷ|Ỵ|Ỹ"]
    list_re = ['a', 'A', 'd', 'D', 'i', 'I', 'e', 'E', 'o', 'O', 'u', 'U', 'y', 'Y']
    for i in range(len(list_pat)):
      str = re.sub(list_pat[i], list_re[i], str)
    return str
  except:
    traceback.print_exc()
  return str

def normalKeyword(keyword):
  keyword = convertVNChars2NoAccent(keyword)
  return re.sub("\s+","-",keyword)

def isPhimbo(url):
  mediaLink = getMediaLink(url)
  if mediaLink == '':
    if len(getEpisodeInfoList(url)) > 0:
      return True
  return False

# Display Films before playing. These film are playable.
def displayFilms(url):
  ok = True
  phimleInfoList = getFilmInfoList(url)
  for (title, link, icon) in phimleInfoList:
    addDir(title, link, 1, icon)
  return ok



# ============================================ SCREENs ===================================================


# mode = 0
def homeScreen(url):
  ok=True
  filmTypeList = getFilmTypeList(url)
  if len(filmTypeList) > 0:
    for (filmType, filmLink) in filmTypeList:
      # FIXME: Hard code for phim-le and phim-bo
      phimleLink = url + "phim-le/"
      phimboLink = url + "phim-bo/"
      if filmLink == phimleLink:
        displayFilms(filmLink)
      elif filmLink == phimboLink:
        addDir(filmType, filmLink, 2, '')
      else:
        addDir(filmType, filmLink, 4, '')
    findFilmLink = url + "tim-kiem/"
    addDir("Tìm Phim", findFilmLink, 5, '')
  endOfItemList()
  return ok

# mode = 1
def filmScreen(title, filmLink, thumbnail):
  mediaLink = getMediaLink(filmLink)
  return playMedia(title, mediaLink, thumbnail)
  
# mode = 2
def phimboScreen(title, filmLink):
  ok = True
  phimboInfoList = getFilmInfoList(filmLink)
  if len(phimboInfoList) <= 0:
    return ok
  for (title, link, thumbnail) in phimboInfoList:
    addDir(title, link, 3, thumbnail)
  endOfItemList()
  return ok

# mode = 3
def episodesScreen(title, link, thumbnail):
  ok = True
  epsInfoList = getEpisodeInfoList(link)
  if (len(epsInfoList) > 0):
    for (eps, epsLink) in epsInfoList:
      epsTitle = title + ' - Tập ' + eps
      addDir(epsTitle, epsLink, 1, thumbnail)
  endOfItemList()
  return ok

# mode = 4
def showClipScreen(url):
  ok = displayFilms(url)
  endOfItemList()
  return ok

# mode = 5
def searchFilm(url):
  ok = True
  searchText = ''
  try:
    keyb=xbmc.Keyboard('', '[COLOR lime]NHẬP TÊN PHIM CẦN TÌM KIẾM[/COLOR]')
    keyb.doModal()
    if (keyb.isConfirmed()):
      searchText = normalKeyword(keyb.getText())
  except: pass
  url = url + searchText
  filmInfoList = getFilmInfoList(url)
  for (title, link, icon) in filmInfoList:
    addDir(title, link, 6, icon)
  endOfItemList()
  return ok

def playByFilmType(title, filmLink, thumbnail):
  mediaLink = getMediaLink(filmLink)
  if mediaLink == '':
    return episodesScreen(title, filmLink, thumbnail)
  else:
    return playMedia(title, mediaLink, thumbnail)

def get_params():
  param=[]
  paramstring=sys.argv[2]
  if len(paramstring)>=2:
    params=sys.argv[2]
    cleanedparams=params.replace('?','')
    if (params[len(params)-1]=='/'):
      params=params[0:len(params)-2]
    pairsofparams=cleanedparams.split('&')
    param={}
    for i in range(len(pairsofparams)):
      splitparams={}
      splitparams=pairsofparams[i].split('=')
      if (len(splitparams))==2:
        param[splitparams[0]]=splitparams[1]
  return param

def setResolvedUrl(url):
  item=xbmcgui.ListItem(path=url)
  xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

# TODO: Uncomment!
def playMedia(name,url,iconimage):
  # print('\n\r\nplayMedia: ' + url + '\n\n')
  liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
  liz.setInfo( type="Video", infoLabels={ "Title": name } )
  # setResolvedUrl(url)
  xbmc.Player().play(url, liz)
  return True

def addLink(name,url,iconimage,mode=0):
  u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&thumbnail="+urllib.quote_plus(iconimage)
  ok=True
  liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
  liz.setInfo( type="Video", infoLabels={ "Title": name } )
  liz.setProperty('IsPlayable', 'true')
  ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
  return ok


# TODO: Uncomment!
def addDir(name,url,mode,iconimage):
  # print('------------------------')
  # print(name)
  # print('- URL: ' + url)
  # print('- MODE: ' + str(mode))
  # print('- Icon: ' + iconimage)
  # print('------------------------ \n')
  u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&thumbnail="+urllib.quote_plus(iconimage)
  ok=True
  liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
  liz.setInfo( type="Video", infoLabels={ "Title": name } )
  liz.setProperty('Fanart_Image',fanart)
  ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
  return ok

# --------------------------------------------

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

# TODO: Uncomment!
params=get_params()

url=None
name=None
mode=None
thumbnail=''

# TODO: Uncomment!
try:
  url=urllib.unquote_plus(params["url"])
except:
  pass
try:
  name=urllib.unquote_plus(params["name"])
except:
  pass
try:
  mode=int(params["mode"])
except:
  pass
try:
  thumbnail=urllib.unquote_plus(params["thumbnail"])
except:
  pass

# ---------------------------- MODE SELECTION ------------------------

# mode = 0
if mode==None or url==None or len(url)<1:
  homeScreen(rootURL)

elif mode == 1:
  filmScreen(name, url, thumbnail)

# List all "Phim Bo"
elif mode == 2:
  phimboScreen(name, url)

# Display all episodes of a "Phim Bo"
elif mode == 3:
  episodesScreen(name, url, thumbnail)

# Display "Show", "Clip" screen.
elif mode == 4:
  showClipScreen(url)

# For searching film
elif mode == 5:
  searchFilm(url)

elif mode == 6:
  playByFilmType(name, url, thumbnail)

# -*- coding: utf-8 -*-

'''
Copyright (C) 2014                                                     

This program is free software: you can redistribute it and/or modify   
it under the terms of the GNU General Public License as published by   
the Free Software Foundation, either version 3 of the License, or      
(at your option) any later version.                                    

This program is distributed in the hope that it will be useful,        
but WITHOUT ANY WARRANTY; without even the implied warranty of         
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
GNU General Public License for more details.                           

You should have received a copy of the GNU General Public License      
along with this program. If not, see <http://www.gnu.org/licenses/>  
'''                                                                           

import urllib,urllib2,re,os
import xbmcplugin,xbmcgui,xbmcaddon

settings  = xbmcaddon.Addon(id='plugin.video.TVCatchup')
profile   = settings.getAddonInfo('profile')
home      = settings.getAddonInfo('path')
fanart    = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon      = xbmc.translatePath(os.path.join(home, 'icon.png'))
logos     = xbmc.translatePath(os.path.join(home, 'logos\\'))
tvcatchup ='http://103.31.126.20/tvcatchup/'


def main():
  addDir('VTV1',tvcatchup,1,logos+'VTV1.png')
  addDir('VTV2',tvcatchup,1,logos+'VTV2.png')
  addDir('VTV3',tvcatchup,1,logos+'VTV3.png')
  addDir('VTV6',tvcatchup,1,logos+'VTV6.png')
  addDir('TODAY-TV',tvcatchup,1,logos+'TODAY-TV.png')  
  addDir('AXN',tvcatchup,1,logos+'AXN.png')
  addDir('FOXSPORT',tvcatchup,1,logos+'FOX.png')
  addDir('HBO',tvcatchup,1,logos+'HBO.png')
  addDir('STARMOVIES',tvcatchup,1,logos+'STARMOVIES.png')  
 	  
def Index(name):
  content=GetURL(tvcatchup)
  if 'VTV1' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:	
      addDir(name,tvcatchup+url,101,logos+'VTV1.png')
  elif 'VTV2' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:  
      addDir(name,tvcatchup+url,102,logos+'VTV2.png')
  elif 'VTV3' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:  
      addDir(name,tvcatchup+url,103,logos+'VTV3.png')
  elif 'VTV6' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:  
      addDir(name,tvcatchup+url,104,logos+'VTV6.png')
  elif 'TODAY-TV' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:  
      addDir(name,tvcatchup+url,105,logos+'TODAY-TV.png')	  
  elif 'AXN' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:  
      addDir(name,tvcatchup+url,106,logos+'AXN.png')
  elif 'FOXSPORT' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:  
      addDir(name,tvcatchup+url,107,logos+'FOXSPORT.png')	  
  elif 'HBO' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:  
      addDir(name,tvcatchup+url,108,logos+'HBO.png')
  elif 'STARMOVIES' in name:  
    match=re.compile('href="(\d+)/">(\d+)/<').findall(content)
    for url,name in match:  
      addDir(name,tvcatchup+url,109,logos+'STARMOVIES.png')

def Get_VTV1(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'VTV1' in name:  
      addLink(name,url+'/'+href,logos+'VTV1.png')	  

def Get_VTV2(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'VTV2' in name:  
      addLink(name,url+'/'+href,logos+'VTV2.png')

def Get_VTV3(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'VTV3' in name:  
      addLink(name,url+'/'+href,logos+'VTV3.png')
	  
def Get_VTV6(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'VTV6' in name:  
      addLink(name,url+'/'+href,logos+'VTV6.png')	  

def Get_TODAYTV(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'TODAYTV' in name:  
      addLink(name,url+'/'+href,logos+'TODAYTV.png')
	  
def Get_AXN(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'AXNHD' in name:  
      addLink(name,url+'/'+href,logos+'AXN.png')
	  
def Get_FOX(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'FOXSPORTHD' in name:  
      addLink(name,url+'/'+href,logos+'FOXSPORT.png')

def Get_HBO(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'HBOHD' in name:  
      addLink(name,url+'/'+href,logos+'HBO.png')	  

def Get_STARMOVIES(url):
  content=GetURL(url)
  match=re.compile('<a href="(.+?)">(.+?)\.mp4</a>').findall(content)
  for href, name in match:
    if 'STARMOVIESHD' in name:  
      addLink(name,url+'/'+href,logos+'STARMOVIES.png')
	  
def GetURL(url):
  try:
    req=urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
    response=urllib2.urlopen(req, timeout=90)
    link=response.read()
    response.close()  
    return link
  except urllib2.URLError, e:
    print 'We failed to open "%s".' % url
    if hasattr(e, 'code'):
      print 'We failed with error code - %s.' % e.code	
    if hasattr(e, 'reason'):
      print 'We failed to reach a server.'
      print 'Reason: ', e.reason
	  
def get_params():
  param=[]
  paramstring=sys.argv[2]
  if len(paramstring)>=2:
    params=sys.argv[2]
    cleanedparams=params.replace('?','')
    if (params[len(params)-1]=='/'):
      params=params[0:len(params)-2]
    pairsofparams=cleanedparams.split('&')
    param={}
    for i in range(len(pairsofparams)):
      splitparams={}
      splitparams=pairsofparams[i].split('=')
      if (len(splitparams))==2:
        param[splitparams[0]]=splitparams[1]
  return param
	
def addDir(name,url,mode,iconimage):
  u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
  ok=True
  liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
  liz.setInfo( type="Video", infoLabels={ "Title": name } )
  ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
  return ok
 	
def addLink(name,url,iconimage):
  ok=True
  liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
  liz.setInfo( type="Video", infoLabels={ "Title": name } )
  ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
  return ok
   
params=get_params()
url=None
name=None
mode=None
iconimage=None

try:
  url=urllib.unquote_plus(params["url"])
except:
  pass
try:
  name=urllib.unquote_plus(params["name"])
except:
  pass
try:
  mode=int(params["mode"])
except:
  pass
try:
  iconimage=urllib.unquote_plus(params["iconimage"])
except:
  pass  
 
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "iconimage: "+str(iconimage)

if mode==None or url==None or len(url)<1:
  main()

elif mode==1:
  Index(name)  

elif mode==101:
  Get_VTV1(url)

elif mode==102:
  Get_VTV2(url)

elif mode==103:
  Get_VTV3(url)

elif mode==104:
  Get_VTV6(url)

elif mode==105:
  Get_TODAYTV(url)
  
elif mode==106:
  Get_AXN(url)
  
elif mode==107:
  Get_FOX(url)

elif mode==108:
  Get_HBO(url)  

elif mode==109:
  Get_STARMOVIES(url)
  
xbmcplugin.endOfDirectory(int(sys.argv[1]))
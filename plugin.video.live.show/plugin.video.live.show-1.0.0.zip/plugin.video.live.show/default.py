# -*- coding: utf-8 -*-

'''
Copyright (C) 2014                                                     

This program is free software: you can redistribute it and/or modify   
it under the terms of the GNU General Public License as published by   
the Free Software Foundation, either version 3 of the License, or      
(at your option) any later version.                                    

This program is distributed in the hope that it will be useful,        
but WITHOUT ANY WARRANTY; without even the implied warranty of         
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
GNU General Public License for more details.                           

You should have received a copy of the GNU General Public License      
along with this program. If not, see <http://www.gnu.org/licenses/>  
'''                                                                           

import urllib,urllib2,re,os,base64
import xbmcplugin,xbmcgui,xbmcaddon

mysettings=xbmcaddon.Addon(id='plugin.video.live.show')
profile=mysettings.getAddonInfo('profile')
home=mysettings.getAddonInfo('path')
icon=xbmc.translatePath(os.path.join(home, 'icon.png'))
logos=xbmc.translatePath(os.path.join(home, 'logos\\'))
dataPath = xbmc.translatePath(os.path.join(home, 'resources'))
		
def main():
  addDir('[COLOR FF0084EA]Asia[/COLOR] Entertainment','Asia',1,logos + "ASIA.png")
  addDir('[COLOR red]Thúy Nga[/COLOR] Entertainment','ThuyNga',1,logos + "THUYNGA.png")
  addDir('[COLOR magenta]Vân Sơn[/COLOR] Entertainment','VanSon',1,logos + "VANSON.png")  
  skin_used = xbmc.getSkinDir()
  if skin_used == 'skin.xeebo':
    xbmc.executebuiltin('Container.SetViewMode(50)')  

def dir():
  if 'Asia' in name:
    match=menulist(dataPath+'/data/ASIA.xml')
    for title,url,thumbnail in match:
      addLink(title,url,thumbnail)
  elif 'Vân Sơn' in name:
    match=menulist(dataPath+'/data/VANSON.xml')
    for title,url,thumbnail in match:
      addLink(title,url,thumbnail)
  elif 'Thúy Nga' in name:
    addDir('Thúy Nga | Full Colection','ThuyNga',2,logos + "THUYNGA.png")
    addDir('Thúy Nga | Tổng Hợp','http://ott.thuynga.com/vi/genre/index/22/3',3,logos + "THUYNGA.png")
    addDir('Thúy Nga | Hài Kịch','http://ott.thuynga.com/vi/genre/index/26/3',3,logos + "THUYNGA.png")
    addDir('Thúy Nga | Hậu Trường','http://ott.thuynga.com/vi/genre/index/64/3',3,logos + "THUYNGA.png")
  skin_used = xbmc.getSkinDir()	
  if skin_used == 'skin.xeebo':
    xbmc.executebuiltin('Container.SetViewMode(50)')	  

def Thuynga_special():
  match=menulist(dataPath+'/data/THUYNGA.xml')
  for title,url,thumbnail in match:
    addLink(title,url,thumbnail)

def Thuynga_Url(url):
  content=Get_Url(url)
  match=re.compile("style=\"background-image: url\('(.+?)'\)\">\s*<span class.+?</span>\s.+\s.+\s.+\s*<a href=\"(.+?)\">(.+?)<").findall(content)
  for thumbnail,url,name in match:
    addLink(name,'http://ott.thuynga.com/'+url,thumbnail+'?.jpg')
  match=re.compile('href="http://ott.thuynga.com/([^>]+)">(\d+)<').findall(content)	
  for url,name in match:
	addDir('[COLOR lime]Trang ' + name + '[/COLOR]','http://ott.thuynga.com/'+url,3,'')	
	
def menulist(homepath):
  try:
    mainmenu=open(homepath, 'r')  
    content=mainmenu.read()
    mainmenu.close()
    match=re.findall('<title>([^>]*)<\/title>\s*<link>(.+?)<\/link>\s*<thumbnail>([^<]*)<\/thumbnail>', get_link(content))
    return match
  except:
    pass	
       
def Get_Url(url):
    try:
		req=urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)')
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()  
		return link
    except:
		pass
	
def resolveUrl(url):
	if 'ott.thuynga' in url:
		content = Get_Url(url)	
		url=re.compile("var iosUrl = '(.+?)'").findall(content)[0]		
	else:
		url = url
	item=xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)	  
	return

def get_params():
  param=[]
  paramstring=sys.argv[2]
  if len(paramstring)>=2:
    params=sys.argv[2]
    cleanedparams=params.replace('?','')
    if (params[len(params)-1]=='/'):
      params=params[0:len(params)-2]
    pairsofparams=cleanedparams.split('&')
    param={}
    for i in range(len(pairsofparams)):
      splitparams={}
      splitparams=pairsofparams[i].split('=')
      if (len(splitparams))==2:
        param[splitparams[0]]=splitparams[1]
  return param
				  
def addDir(name,url,mode,iconimage):
  u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
  ok=True
  liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
  liz.setInfo( type="Video", infoLabels={ "Title": name } )
  ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
  return ok
   
def addLink(name,url,iconimage):
  u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode=4"  
  liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
  liz.setInfo( type="Video", infoLabels={ "Title": name } )
  liz.setProperty('IsPlayable', 'true')  
  ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)  

get_link = base64.b64decode  
params=get_params()
url=None
name=None
mode=None

try:
  url=urllib.unquote_plus(params["url"])
except:
  pass
try:
  name=urllib.unquote_plus(params["name"])
except:
  pass
try:
  mode=int(params["mode"])
except:
  pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:main() 
elif mode==1:dir()
elif mode==2:Thuynga_special()
elif mode==3:Thuynga_Url(url)
elif mode==4:
  dialogWait = xbmcgui.DialogProgress()
  dialogWait.create('[COLOR yellow]Giải [COLOR cyan]trí [COLOR tan]On[COLOR coral]line[/COLOR]', '[COLOR orange]Loading. Please wait...[/COLOR]')
  resolveUrl(url)
  dialogWait.close()
  del dialogWait
 
xbmcplugin.endOfDirectory(int(sys.argv[1]))